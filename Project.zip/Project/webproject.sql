-- Database: `webproject`

-- --------------------------------------------------------


start transaction;


-- Table structure for table `categories`

CREATE TABLE `categories` (
  id int(11) NOT NULL,
  name varchar(255) NOT NULL,
  filename varchar(255) NOT NULL
);

-- Dumping data for table `categories`

INSERT INTO categories (id, name, filename) VALUES
(1, 'Lamborghini', 'img/Lamborghini_Logo.svg.png'),
(2, 'Ferrari', 'img/Ferrari-Logo.png'),
(3, 'Porsche', 'img/Porsche-Logo.png'),
(4, 'Mercedes', 'img/Mercedes-Logo.svg.png'),
(5, 'Audi', 'img/audi.png'),
(6, 'BMW', 'img/BMW.svg.png');



ALTER TABLE categories
  ADD PRIMARY KEY (id);


ALTER TABLE categories
  MODIFY id int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--AUTO_INCREMENT=7:
--each time a new row 
--is inserted into the categories table without specifying a value for the id column,
-- MySQL will automatically assign it the next available integer value, starting from 7


-- --------------------------------------------------------






-- Table structure for table `products`


CREATE TABLE products (
  id int(11) NOT NULL,
  name varchar(255) NOT NULL,
  color varchar(255) NOT NULL,
  speed varchar(255) NOT NULL,
  model int(11) NOT NULL,
  description longtext NOT NULL,
  catid int(11) NOT NULL,
  filename varchar(255) NOT NULL,
  price varchar(255) NOT NULL
);


ALTER TABLE products
  ADD PRIMARY KEY (id);

ALTER TABLE products
  MODIFY id int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

ALTER TABLE products
ADD COLUMN quantity int(11) NOT NULL DEFAULT 0;
--  int(11): This specifies the data type of the column, which is integer. 
--  The number in parentheses (11) is the display width, indicating the maximum number of digits the column can hold. 

--  NOT NULL: This constraint indicates that the quantity column cannot contain null values. Every row in the table must have a value for this column.

--  DEFAULT 0: This specifies a default value of 0 for the quantity column. 
--  If a value is not explicitly provided for this column during an INSERT operation, it will default to 0.



UPDATE products
SET quantity = 3; 


ALTER TABLE products
ADD COLUMN seller_id INT NOT NULL;


-- Dumping data for table `products`

INSERT INTO products (id, name, color, speed, model, description, catid, filename, price,seller_id) VALUES
(1, 'Lamborghini Revuelto', 'Orange', '124mph', 2020, 'Lambo claims Revuelto has the best power-to-weight ratio of any vehicle the brand has ever produced, as well as its fastest road car to date—roaring from 0 to 62mph in only 2.5 seconds and 124mph in under seven.', 1, 'img/Lamborghini-2.jpg', '$250,000',1),
(2, 'Lamborghini Huracan', 'Green', '150mph', 2021, 'The Lamborghini Huracán is the perfect fusion of technology and design. With its crisp, streamlined lines, designed to cut through the air and tame the road', 1, 'img/Lamborghini-1.jpg', '$250,000',1),
(3, 'ASD Lamborghini', 'Cyan', '150mph', 2022, 'Its an exclusive car for ASD Car show Company,The Lamborghini Aventador is one of the most exotic-looking cars in the world, and its final form roars into the sunset in limited numbers with a 769-hp V-12', 1, 'img/lamborghini.jpg', '$1,000,000',1),
(4, 'Ferrari Portofino M', 'Silver', '150mph', 2017, 'The Ferrari Portofino M rediscovers convertible driving with technical and design innovations, such as the 620 cv engine and a five-position Manettino.', 2, 'img/Ferrari-2.jpg', '$1,200,000',2),
(5, 'Ferrari 812 GTS', 'Grey', '140mph', 2019, 'Ferrari 812 GTS, speed meets elegance in the new V12 spider featuring a 800 CV engine.', 2, 'img/Ferrari-4.jpg', '$900,000',2),
(6, 'Ferrari 296 GTS', 'Blue and White', '120mph', 2018, 'The Ferrari 296 GTS, the evolution of Ferrari\'s mid-rear-engined two-seater berlinetta spider concept, is powered by the new 120° V6 engine', 2, 'img/Ferrari-3.jpg', '$1,000,000',2),
(7, 'Porsche Cayenne', 'Dark cyan', '120mph', 2020, 'The Cayenne models. Drive a Sports Cars for the whole family. Including luggage. An overview of all model variants and equipment details.', 3, 'img/Porsche-1.jpg', '$1,100,000',3),
(8, 'Porsche 911 GT3 R', 'Black', '130mph', 2019, 'The new 911 GT3 R is driven by a water-cooled four-liter four-valve flat-six engine in the rear. The direct fuel injection (DFI) ensures maximum fuel efficiency', 3, 'img/Porsche-2.jpg', '$1,200,000',3),
(9, 'Mercedes-Benz S63', 'Silver', '130mph', 2019, 'Focusing its plug-in hybrid powertrain for power instead of range, the 2023 Mercedes-AMG S63 is a most comfortable way to experience 791 horsepower.', 4, 'img/Mercedes-1.jpg', '$200,000',4),
(10, 'Mercedes-Benz EQE', 'Blue', '120mph', 2023, 'The EQE Sedan is innovative, luxurious and intelligent. See design, performance and technology features, as well as models, pricing, photos and more.', 4, 'img/Mercedes-2.jpg', '$250,000',4),
(11, 'Audi S8', 'Blue', '130mph', 2018, 'Audi offers the new Q8 e-tron in two body variants: as a classic SUV and as a Sportback that combines the spaciousness of an SUV with the elegant lines', 5, 'img/Audi-1.jpg', '$290,000',5),
(12, 'Audi SQ8 Sportback', 'Blue', '140mph', 2013, 'The Audi S8 Sportback e-tron has a high-speed DC charging capacity of 170 kW at public stations - enabling a charge from 10% to 80% in around 31 minutes', 5, 'img/Audi-2.jpg', '$300,000',5),
(13, 'BMW M8', 'Light Blue', '150mph', 2022, 'The M8 Competition Coupe\'s 4.4-liter V-8 engine delivers 617 horsepower and features an advanced cooling system, and a uniquely designed dual oil pan', 6, 'img/BMW-1.jpg', '$270,000',6),
(14, 'BMW X5 M', 'Green', '120mph', 2024, 'The BMW X5 M Competition manifests its claim to leadership with powerful proportions, exclusive M design and outstanding performance.\r\n', 6, 'img/BMW-3.jpg', '$200,000',6);

-- --------------------------------------------------------






-- Table structure for table `users`

CREATE TABLE users (
  id int(11) NOT NULL,
  username varchar(255) NOT NULL,
  email varchar(255) NOT NULL,
  password varchar(255) NOT NULL
);

-- Dumping data for table `users`

INSERT INTO users (id, username, email, password) VALUES
(1, 'a123', 'abdallahhamdan40@gmail.com', '1234'),
(2, 'm123', 'mhmd123@gmail.com', '1234'),
(3, 'n123', 'abd12@gmail.com', '1234'),
(4, 'aa123', 'ali12@gmail.com', '1234');


ALTER TABLE users
  ADD PRIMARY KEY (id);


ALTER TABLE users
  MODIFY id int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

-- --------------------------------------------------------






-- Table structure for table `purchases`

CREATE TABLE purchase_Info (
  PurchaseNo int(11) NOT NULL AUTO_INCREMENT,
  ProductId int(11) NOT NULL,
  ProductName varchar(255) NOT NULL,
  ProductPrice varchar(255) NOT NULL,
  Seller_id INT,
  PRIMARY KEY (PurchaseNo)
);


-- Add auto-increment for `PurchaseNo`
ALTER TABLE purchase_Info
MODIFY PurchaseNo int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

-- --------------------------------------------------------


-- Create the retail_center table
CREATE TABLE retail_center (
  branch_id VARCHAR(20),
  seller_id INT,
  name VARCHAR(100),
  phone_number VARCHAR(20),
  email VARCHAR(100),
  address VARCHAR(200),
  product_id INT,
  PRIMARY KEY (branch_id)
);

-- Insert data into the retail_center table
INSERT INTO retail_center (branch_id,seller_id,name, phone_number, email, address,product_id) VALUES
  ('Bei',    1,   'Lamborghini', '07123456',     'Lamborghini@gmail.com',    'Beirut',     1),
  ('Tri',    1,   'Lamborghini', '07123456',     'Lamborghini@gmail.com',    'Beirut',     2),
  ('Sid',    1,   'Lamborghini', '07123456',     'Lamborghini@gmail.com',    'Beirut',     3),
  
  ('Baa',    2,   'Ferrari',     '07654321',     'Ferrari@gmail.com',        'Tyre',       4),
  ('Tyr',    2,   'Ferrari',     '07654321',     'Ferrari@gmail.com',        'Tyre',       5),
  ('Nab',    2,   'Ferrari',     '07654321',     'Ferrari@gmail.com',        'Tyre',       6),

  ('Ale',    3,   'Porsche',     '07456789',     'Porsche@gmail.com',        'Saida',      7),
  ('Jou',    3,   'Porsche',     '07456789',     'Porsche@gmail.com',        'Saida',      8),


  ('Zah',    4,   'Mercedes',    '07101011',     'Mercedes@gmail.com',       'Batroun',    9),
  ('Zgh',    4,   'Mercedes',    '07101011',     'Mercedes@gmail.com',       'Batroun',    10),

  ('Byb',    5,   'Audi',        '07111222',     'Audi@gmail.com',           'Tripoli',    11),
  ('Bat',    5,   'Audi',        '07111222',     'Audi@gmail.com',           'Tripoli',    12),

  ('Bri',    6,   'BMW',         '07121212',     'BMW@gmail.com',            'Beirut',     13),
  ('Ach',    6,   'BMW',         '07121212',     'BMW@gmail.com',            'Beirut',     14);



ALTER TABLE retail_center
ADD COLUMN Provided_Quantity int(11) NOT NULL DEFAULT 0;


UPDATE retail_center
SET Provided_Quantity = 3; 


COMMIT;


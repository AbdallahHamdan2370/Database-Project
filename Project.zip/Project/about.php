<?php
include('connecttodb.php');
?>

<html>

<head>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Concert+One&family=Flow+Circular&family=Luckiest+Guy&family=Poppins:wght@300;400;500;600;700&family=Righteous&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
        integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
        crossorigin="anonymo us" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="landingpage.css">
</head>

<body>
    <div>
        <?php
        include('nav.html');
        ?>
    </div>
    <div class="about-page">
        <header>
            <p>Best Quality in Town</p>
            <h1>About <span>Us</span></h1>
        </header>
        <div class="main">
            <div class="left-about">
                <h3>What is <span>Triple A CarShop</span> ?</h3>
                <p>Welcome to Triple A CarShop, a luxury car company dedicated to providing our customers with the finest
                    selection of high-end vehicles on the market. <br>
                    <br>

                    At Triple A CarShop, we understand that owning a luxury car is more than just a means of transportation;
                    it's
                    a symbol of success, style, and sophistication. That's why we offer a wide range of luxury cars,
                    from
                    sleek sports cars to powerful SUVs, all designed to cater to your individual preferences and
                    needs.<br>
                    <br>

                    Our team of experts is committed to delivering an exceptional buying experience, ensuring that every
                    detail is taken care of from start to finish. We strive to provide personalized service to each of
                    our
                    clients, ensuring that they receive the attention and care they deserve.<br>
                    <br>

                    We are passionate about luxury cars, and our inventory reflects that. We handpick only the finest
                    vehicles, each of which is rigorously inspected and maintained to ensure the highest quality. We
                    pride
                    ourselves on offering a diverse selection of vehicles from the world's most prestigious brands,
                    including Ferrari, Lamborghini, Porsche, and many others.<br>
                    <br>
                    At Triple A CarShop, we also offer a variety of services to ensure that your luxury car ownership
                    experience
                    is as smooth and enjoyable as possible. Our team of experienced mechanics provides top-notch
                    maintenance
                    and repair services, and our financing department offers competitive rates and flexible payment
                    options.<br>
                    <br>

                    We believe that luxury car ownership should be an experience, and we strive to make that a reality
                    for
                    each of our customers. Thank you for considering Triple A CarShop for your luxury car needs, and we look
                    forward to serving you soon.

                </p>
            </div>
            <div class="right-about">
                <img src="img/negotiations1.jpg" alt="">
            </div>
        </div>
    </div>
    

</body>
<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        text-decoration: none;
    }

    div {
        height: fit-content;
    }

    body {
        min-height: 100vh;
    }

    .about-page {
        padding: 0px 90px;
        min-height: 80vh;
        position: absolute;
        top: 20%;
        width: 100%;
    }

    .about-page header {
        text-align: left;
        width: 100%;
    }

    header h1 {
        font-size: 40px;
    }

    .main {
        display: flex;
        position: relative;
    }

    .right-about img {
        width: 100%;
        height: 400px;
    }

    .left-about {
        margin-top: 30px;
        width: 55%;
        margin-right: 20px;
    }

    .right-about {
        width: 45%;
        margin-top: 30px;
    }

    h3 {
        margin-bottom: 20px;
    }
    .footer {
        position: absolute;
        top: 170%;
        width: 100%;
    }
    @media (max-width:985px) {
        .main {
            flex-direction: column-reverse;
        }

        .right-about {
            width: 100%;
            margin-top: 30px;
        }

        .left-about {
            margin-top: 30px;
            width: 100%;

        }

        .about-page {
            padding: 0 30px;
        }
        .footer {
            top: 280%;
        }
    }
   
</style>

</html>
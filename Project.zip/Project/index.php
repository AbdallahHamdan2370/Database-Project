<?php
include('connecttodb.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Triple A CarShop</title>
  <link rel="stylesheet" href="landingpage.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=Concert+One&family=Flow+Circular&family=Luckiest+Guy&family=Poppins:wght@300;400;500;600;700&family=Righteous&display=swap"
    rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
    crossorigin="anonymo us" referrerpolicy="no-referrer" />
  <script src="landing.js" defer></script>
</head>

<body>
  <?php
  include('nav.html');
  ?>
  <section id="home">
    <div class="container">
      <h1>Life is too short to Drive<br> Boring <span>Cars!</span></h1>
      <p>Pick up your dream car from our store!!!!</p>
      <div class="btn">
        <a href="products.php">
          <button>Discover More</button>
          <i class="fa-solid fa-arrow-up-right-from-square"></i>
        </a>
      </div>
    </div>
    </div>
    <div id="slider-wrapper">
      <div class="slider">
        <div class="slide first">
          <img style="filter: brightness(0.4);" src="img/ferrari.jpg" alt="age 1">
        <
      </div>
    </div>

    </div>

  </section>
  <section id="about">

    <header>
      <p>About Us</p>
      <h1>Best <span>Customer</span> Experience</h1>
    </header>
    <div class="items">
      <div class="left-about">
        <img src="img/about.jpg" alt="image">
      </div>
      <div class="right-about">
        <div class="top"><span>About</span>
        </div>
        <p>Our website that is about car company is a comprehensive resource for anyone interested in cars. It showcases
          a variety of cars from different brands.
          <br><br> Visitors can easily browse and compare different vehicles. Whether someone is in the market for a new
          car or merely looking to stay informed, our website is an excellent destination for all things
          related to cars. <br>You can check our vehicles here!
        </p>
        <div class="btn-2">
          <a href="about.php">
            <button class="btn2">Learn More</button>
            <i class="fa-solid fa-arrow-up-right-from-square"></i>
          </a>
        </div>
      </div>
    </div>
  </section>
  <section id="categories" class="categories">

    <?php
    $query = 'SELECT * FROM categories';

    $result = mysqli_query($db, $query);


    ?>
    <div class="cat-header">
      <h1>Our <span>Categories</span></h1>
    </div>
    <div class="cat-grid">
  <?php while ($record = mysqli_fetch_assoc($result)) { 
    $cname = $record['name'];
    $cid = $record['id'];
    $cimg = $record['filename'];
  ?>
    <a class="cat-a" href="categories.php?cid=<?php echo $cid; ?>" class="cat-link">
      <div class="image-item">
        <img class="cat-img" src="<?php echo $cimg; ?>" alt="<?php echo $cname; ?>">
        <h2><?php echo $cname; ?></h2>
      </div>
    </a>
  <?php } ?>
</div>


  </section>
  <section class="reviews" id="reviews">
    <header>
      <p>REVIEWS</p>
      <h1>What our <span>Customers</span> Say</h1>
    </header>
    <div class="container-reviews">
      <div class="review">
        <header>
          <img src="img/face1.jpg" alt="">
          <div class="content">
            <h2>John Smith</h2>
            <div class="stars">
              <i class="fa-sharp fa-solid fa-star"></i>
              <i class="fa-sharp fa-solid fa-star"></i>
              <i class="fa-sharp fa-solid fa-star"></i>
              <i class="fa-sharp fa-solid fa-star"></i>
              <i class="fa-sharp fa-solid fa-star-half-stroke half"></i>
            </div>
          </div>
        </header>
        <div class="text">
          <p> I am extremely satisfied with my BMW purchase and would highly recommend this car company to anyone
            looking for a quality vehicle backed by excellent customer service.</p>
        </div>
      </div>
      <div class="review">
        <header>
          <img src="img/face3.jpg" alt="">
          <div class="content">
            <h2>Alena Trump</h2>
            <div class="stars">
              <i class="fa-sharp fa-solid fa-star"></i>
              <i class="fa-sharp fa-solid fa-star"></i>
              <i class="fa-sharp fa-solid fa-star"></i>
              <i class="fa-sharp fa-solid fa-star"></i>
              <i class="fa-sharp fa-solid fa-star-half-stroke half"></i>
            </div>
          </div>
        </header>
        <div class="text">
          <p>Once I made my purchase, the after-sales service has been exceptional. The service team is prompt,
            efficient, and always willing to go the extra mile to ensure that my car is running smoothly. </p>
        </div>
      </div>
      <div class="review">
        <header>
          <img src="img/face2.webp" alt="">
          <div class="content">
            <h2>Micheal Ballack</h2>
            <div class="stars">
              <i class="fa-sharp fa-solid fa-star"></i>
              <i class="fa-sharp fa-solid fa-star"></i>
              <i class="fa-sharp fa-solid fa-star"></i>
              <i class="fa-sharp fa-solid fa-star"></i>
              <i class="fa-sharp fa-solid fa-star-half-stroke half"></i>
            </div>
          </div>
        </header>
        <div class="text">
          <p>I recently purchased a lamborghini car from this company and I must say I am thoroughly impressed with the
            quality and performance of their vehicles.<br><br></p>
        </div>
      </div>
    </div>
    <header>
      <p>CONTACT US</p>
      <h1>Keep in <span>Touch</span> with Us</h1>
    </header>
    <div class="contactsss">
      <div class="left-contact">
        <iframe src="https://maps.google.com/maps?q=beirut&t=&z=14&ie=UTF8&iwloc=&output=embed" frameborder="0"
          scrolling="no" marginheight="0" marginwidth="0">
        </iframe>

      </div>
      <div class="right-contact">
      <form action="https://formspree.io/f/mpzvyebr" method="POST">
          <div class="social">
            <h2>Our <span>Social</span> Media</h2>
            <ul>
              <li><a href="https://www.instagram.com/abedtenchassi_?igsh=amsxMmlzOGl6dXc2&utm_source=qr"><i
                    class="fa-brands fa-instagram"></i></a></li>
              <li><a href="https://www.facebook.com/abdulrhmanenchassi.enchassi?mibextid=LQQJ4d"><i class="fa-brands fa-facebook"></i></a></li>
              <li><a href="tel:71145310"><i class="fa-brands fa-whatsapp"></i></a></li>
              <li class="location"><a
                  href="https://www.google.com/maps/place/Beirut,+Lebanon/@33.890368,35.503653,14z/data=!4m6!3m5!1s0x151f17215880a78f:0x729182bae99836b4!8m2!3d33.8937913!4d35.5017767!16zL20vMDlianY?hl=en-US"><i
                    class="fa-sharp fa-solid fa-location-dot"></i></a></li>
            </ul>
          </div>
          <input type="text"  name=" " class="inputtt" id="fname" placeholder="First Name" required>
          <br>
          <input type="text" name=" " class="inputtt" id="lname" placeholder="Last Name" required>
          <br>
          <input type="email" name=" " class="inputtt" id="email-contact" placeholder="Email" required>
          <br>
          <textarea name=" " id="" cols="30" rows="10" required placeholder="Message"></textarea>
          <br>
          <input type="submit" value="Send" class="send">

      </div>

      </form>
    </div>
    </div>
  </section>



  
</body>

</html>
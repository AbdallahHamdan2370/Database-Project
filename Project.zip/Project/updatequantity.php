<?php
include('connecttodb.php');

// Check if product ID is set in the URL
if (isset($_GET['pid'])) {
    $productId = $_GET['pid'];

    // Fetch product details based on product ID
    $query = "SELECT * FROM products WHERE id = $productId";
    $result = mysqli_query($db, $query);

    if ($result) {
        // Fetch product details
        $productData = mysqli_fetch_assoc($result);
        $productName = $productData['name'];
        $productPrice = $productData['price'];
        $sellerId = $productData['seller_id'];

        // Check if quantity is greater than 0
        if ($productData['quantity'] > 0) {
            // Update quantity by decrementing by 1
            $updateQuery = "UPDATE products SET quantity = quantity - 1 WHERE id = $productId";
            $updateResult = mysqli_query($db, $updateQuery);

            if (!$updateResult) {
                echo "Error updating quantity: " . mysqli_error($db);
            } else {
                // Insert purchase into "Purchase_Info" table with Seller_id
                $insertQuery = "INSERT INTO Purchase_Info (ProductId, ProductName, ProductPrice, Seller_id) 
                                VALUES ($productId, '$productName', '$productPrice', $sellerId)";
                $insertResult = mysqli_query($db, $insertQuery);

                if ($insertResult) {
                    echo "Purchase added successfully!";
                } else {
                    echo "Error adding purchase: " . mysqli_error($db);
                }
            }
        } else {
            echo "Product is out of stock!";
            exit; // Exit script if product is out of stock
        }
    } else {
        echo "Error fetching product details: " . mysqli_error($db);
    }
} else {
    echo "Product ID not provided!";
}
?>



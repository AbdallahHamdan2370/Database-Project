<head>
    <link rel="stylesheet" href="landingpage.css">
</head>


<?php
include('connecttodb.php');
include('nav.html');
if (isset($_GET['cid'])) {
    $result = mysqli_query($db, "SELECT * FROM products WHERE catid=" . $_GET['cid']);
    ?>
     <div class="top-products">
        <h1>Triple A <span>Products</span></h1>
     </div>
    <div class="pat-grid">
        <?php while ($record = mysqli_fetch_assoc($result)) {
            $pname = $record['name'];
            $pid = $record['id'];
            $pimg = $record['filename'];
            ?>
            <a class="cat-a" href="product-details.php?pid=<?php echo $pid; ?>">
                <div class="product-item">
                    <img class="pat-img" src="<?php echo $pimg; ?>" alt="<?php echo $pname; ?>">
                    <div class="prod-footer">
                        <h3>
                            <?php echo $pname; ?>
                        </h3>
                        <div class="btn-2">
                            <button class="btn2">View Details</button>
                            <i class="fa-solid fa-arrow-up-right-from-square"></i>
            </a>
        </div>
        </div>

        </div>
        </a>
    <?php } ?>
    </div>
<?php } ?>


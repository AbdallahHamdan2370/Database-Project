<?php
include('connecttodb.php');

$loginFailed = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST["name"]) && isset($_POST["password"])) {

        $name = mysqli_real_escape_string($db, $_POST["name"]);
        $password = md5(mysqli_real_escape_string($db, $_POST["password"]));
        $query = "SELECT * FROM users WHERE username ='$name' AND password ='$password'";
        //$query = "SELECT * FROM users";
        $result = mysqli_query($db, $query);
        $row = mysqli_fetch_assoc($result);

        if ($result->num_rows > 0) {
            // Redirect to index.php upon successful login
            header("Location: index.php");
            exit;
        } else {
            // Set loginFailed to true to display the error message
            $loginFailed = true;
        }
    }
}
?>

<html>

<head>
    <link
        href="https://fonts.googleapis.com/css2?family=Concert+One&family=Flow+Circular&family=Luckiest+Guy&family=Poppins:wght@300;400;500;600;700&family=Righteous&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
        integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="login.css">
</head>

<body style=" width: 100%;
    background: linear-gradient(360deg , rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url(img/lamborghini.jpg);
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;;
    height=100vh;">
    <?php
     include('login.html');
    ?>

    <section class="loginnnnn">
        <form action="" method="POST"> 
            <div class="login-container" id="login">
                <div class="header">
                    <h1 class="h1">LOGIN</h1>
                    <p class="p">Enter your information below</p>
                </div>
                <div class="body">
                    <div class="info">
                        <i class="fa-solid fa-user"></i>
                        <input class="input" name="name" type="text" id="login-name" placeholder="Username" required>
                    </div>
                    <div class="info">
                        <i class="fa-solid fa-lock"></i>
                        <input class="input" name="password" type="password" id="login-password" placeholder="Password"
                            required>
                    </div>
                    <div class="remember">
                        <input type="checkbox" id="check">
                        <label>Remember me</label>
                        <!-- <a href="">Forget Password?</a> -->
                    </div>
                
                    <input type="submit" value="LOGIN" style="  background-color: goldenrod;
                    
    font-size: 17px;
    padding: 10px 120px;
    display:flex;
    align=items:center;
    justify-content:center;
    margin-top:20px;
    cursor:pointer;
    border:0;
    color:rgb(23, 23, 113);
    font-weight:600;
    "
    >
                    <div class="para">
                        <p class="p">Don't have an Account?</p><a href="reg.php"><span class="span" id="signup-btn">Sign
                                up</span></a>
                    </div>

                </div>
                <?php
                // Display error message if login failed
                if ($loginFailed) {
                    echo '<p style="color: red;">Login Failed. Please try again.</p>';
                }
                ?>
            </div>

        </form>



    </section>


    <script>
        //login section
        const signup = document.getElementById('signup-btn');
        const login = document.getElementById('login-btn2');
        const loginpage = document.getElementById('login');
        const signuppage = document.getElementById('signup');
        signup.addEventListener('click', showsignup);
        function showsignup() {
            loginpage.style.display = 'none';
            signuppage.style.display = 'block';
        }
        login.addEventListener('click', showlogin);
        function showlogin() {
            loginpage.style.display = 'block';
            signuppage.style.display = 'none';
        }
    </script>
    
</body>

</html>

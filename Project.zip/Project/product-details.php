<?php

include('connecttodb.php');

?>

<head>
    <link rel="stylesheet" href="landingpage.css">
</head>

<body>
    <?php
    include('nav.html');
    ?>
    <?php
    if (isset($_GET['pid'])) {
        $result = mysqli_query($db, "SELECT * FROM products WHERE id=" . $_GET['pid']);
    }
    ?>
    <div class="pat-grid">
        <?php
        while ($record = mysqli_fetch_assoc($result)) {
            $pname = $record['name'];
            $pid = $record['id'];
            $pimg = $record['filename'];
            $pprice = $record['price'];
            $pdesc = $record['description'];
            $pspeed = $record['speed'];
            $pcolor = $record['color'];
            $pmodel = $record['model'];
            ?>
            <div class="product-detail">
                <img class="pat-img" src="<?php echo $pimg; ?>" alt="<?php echo $pname; ?>">
                <div class="detail-footer">
                    <h3>
                        <?php echo "Name :" . $pname; ?>
                    </h3>
                    <div class="deeeeee">
                        <h3>
                            <?php echo "Model :" ?>
                        </h3>
                        <p>
                            <?php echo $pmodel; ?>
                        </p>
                    </div>
                    <div class="deeeeee">
                    <h3>
                        <?php echo "Price :" ?>
                    </h3>
                    <p>
                        <?php echo $pprice; ?>
                    </p>
                    </div>
                    <div class="deeeeee">
                    <h3>
                        <?php echo "Speed :" ?>
                    </h3>
                    <p>
                        <?php echo $pspeed; ?>
                    </p>
                    </div>
                    <div class="deeeeee">
                    <h3>
                        <?php echo "Color :" ?>
                    </h3>
                    <p>
                        <?php echo $pcolor; ?>
                    </p>
                    </div>
                    
                    <h3 class="descr">
                        <?php echo "Description :" ?>
                    </h3>
                    <p>
                        <?php echo $pdesc; ?>
                    </p>
                   
                    <div class="btn-2">
                        <a href="updatequantity.php?pid=<?php echo $pid; ?>">
                            <button class="btn2">Buy Now</button>

                        </a>
                    </div>
                </div>
            </div>
            </a>
        <?php } ?>
    </div>
    
</body>